import unittest
from DocTest import Addition 

class TestAdd(unittest.TestCase):
    def test_add_asserts_proper_value(self):
        self.assertEqual(Addition(2,3), 5.0)
  # negative test to be failed
    def test_add_asserts_negative(self):
        self.assertEqual(Addition(-2, -5), 7.0)

    def test_add_asserts_str(self):
        self.assertEqual(Addition("Hello", "There"), "HelloThere")    


if __name__ == '__main__':
    unittest.main()