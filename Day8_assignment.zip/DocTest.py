def Addition(num1, num2):
    '''
    Add two numbers
    >>> print(Addition(2, 3))
    5
    
    Add two negative numbers
    >>> print(Addition(-2, -5))
     7
    
    Add two string
    >>> print(Addition("Hello", "There"))
    HelloThere
    '''
    return num1 + num2
      


import doctest
if __name__ == '__main__': 
 doctest.testmod()