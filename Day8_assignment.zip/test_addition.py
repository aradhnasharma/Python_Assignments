import pytest
from DocTest import Addition 

def test_add_asserts_proper_value():
    assert Addition(2,3) == 5.0

def test_add_asserts_negative():
    assert Addition(2, -5) == 7.0

def test_add_asserts_str():
    assert Addition("Hello", "There") == "Hello  There"