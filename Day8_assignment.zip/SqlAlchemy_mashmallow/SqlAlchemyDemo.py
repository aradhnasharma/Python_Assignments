from flask import Flask
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite3'
db = SQLAlchemy(app)

class Employee(db.Model):
    EmpId = db.Column(db.Integer, primary_key=True)
    EmpName = db.Column(db.String(80), primary_key=True)
    Email = db.Column(db.String(120), unique=True, nullable=False)

    def __repr__(self):
      return f"EmpId : {self.EmpId} | EmpName : {self.EmpName} | Email : {self.Email}"
