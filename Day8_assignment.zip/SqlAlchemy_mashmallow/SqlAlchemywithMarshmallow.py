from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite3'

db = SQLAlchemy(app)
ma = Marshmallow(app)

class Employee(db.Model):
    EmpId = db.Column(db.Integer, primary_key=True)
    EmpName = db.Column(db.String(80), primary_key=True)
    Email = db.Column(db.String(120), unique=True, nullable=False)

    def __repr__(self):
     return f"EmpId : {self.EmpId} | EmpName : {self.EmpName} | Email : {self.Email}"

class EmployeeSchema(ma.SQLAlchemySchema):
    class Meta:
        model = Employee
        load_instance = True

    EmpId = ma.auto_field()
    EmpName = ma.auto_field()
    Email = ma.auto_field()

# inserting employee
db.create_all()
Employee_Schema = EmployeeSchema()
obj1 = Employee(EmpId= 1027, EmpName="Singham01" , Email ="Singham01@gmail.com")
obj2 = Employee(EmpId= 1028, EmpName="Suryavanshi01" , Email ="Surya01@gmail.com")
#=Employee.query.filter_by(EmpId=obj1.EmpId).first()
db.session.add(obj1)
db.session.add(obj2)
db.session.commit()     

# printing employee
print(Employee_Schema.dump(obj1))
print(Employee_Schema.dump(obj2))
print(Employee.query.all())