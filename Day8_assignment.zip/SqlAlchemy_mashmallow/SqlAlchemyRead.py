from SqlAlchemyDemo import db
from SqlAlchemyDemo import Employee
db.create_all()
user_1 = Employee(EmpId= 1033, EmpName="hruu" , Email ="hruu@gmail.com")
db.session.add(user_1)
db.session.commit()

#Employee.query.all()
print(Employee.query.all())
#User.query.filter_by(username='admin').first()