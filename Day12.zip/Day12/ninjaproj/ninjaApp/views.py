from django.shortcuts import render, get_object_or_404

# Create your views here.
from .models import Developer
from django.http import HttpResponse

def index(request):
    all_developer = Developer.objects.all()
    context = {
        'all_developer' : all_developer
    }
    return render(request, 'ninjaApp/index.html', context)

def details(request, dev_id):
    dev = get_object_or_404(Developer, pk=dev_id)
    return render(request, 'ninjaApp/details.html', {'dev':dev})
