def exponent(element1, element2):
    return element1 ** element2