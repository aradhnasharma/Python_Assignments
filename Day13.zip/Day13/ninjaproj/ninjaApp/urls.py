from django.urls import path

from . import views
app_name = 'ninjaApp'
urlpatterns = [
    path('',views.index, name='index'),
    path('<int:dev_id>/', views.details, name='details'),
    path('<int:dev_id>/level/', views.level, name='level')
]
