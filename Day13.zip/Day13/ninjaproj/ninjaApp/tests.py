from django.test import TestCase
from django.urls import reverse
from .models import Developer, Skill
from .views import level

class DeveloperTest(TestCase):

    def test_200_index(self):
        
        url = reverse('ninjaApp:index')
        response = self.client.get(url)
        self.assertEquals(response.status_code, 200)

    def test_200_details(self):

        dev = Developer(name='Nishant', experience=15, country='INDIA')
        dev.save()
        url = reverse('ninjaApp:details', args=(dev.id,))
        response = self.client.get(url)
        self.assertEquals(response.status_code, 200)

    def test_404_details(self):

        url = reverse('ninjaApp:details', args=(1,))
        response = self.client.get(url)
        self.assertEquals(response.status_code, 404)

    def test_all_dev(self):
        
        dev = Developer(name='Nishant', experience=15, country='INDIA')
        dev.save()
        dev_list = Developer.objects.all()
        assert len(dev_list) == 1


class SkillMTest(TestCase):

    def test_create_skill(self):
        dev = Developer(name='Nishant', experience=15, country='INDIA')
        dev.save()
        skill = dev.skill_set.create(name='SQL', level=1)
        assert skill.name == 'SQL'

    def test_skill_of_dev(self):
        dev = Developer(name='Nishant', experience=15, country='INDIA')
        dev.save()
        dev.skill_set.create(name='SQL', level=1)
        dev.skill_set.create(name='Python', level=1)
        dev_skill_list = dev.skill_set.all()
        assert len(dev_skill_list) == 2

    def test_level_up(self):
        dev = Developer(name='Nishant', experience=15, country='INDIA')
        dev.save()
        dev.skill_set.create(name='SQL', level=1)
        dev.skill_set.create(name='Python', level=1)
        select = dev.skill_set.get(pk=1)
        select.level += 1
        select.save()
        skill = dev.skill_set.all() 
        assert skill[0].level == 2